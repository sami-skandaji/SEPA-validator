import { BrowserRouter as Router, Routes, Route, Navigate } from "react-router-dom";

import Login from "./components/Login";
import Signup from "./components/Signup";
import Dashboard from "./components/Dashboard";
import Upload from "./components/Upload";
import CompleteProfile from "./components/CompleteProfile";
import PrivateRoute from "./PrivateRoute";
import SepaDetailPage from './components/SepaDetailPage';
import UploadZip from "./components/UploadZip";
import Statistics from "./pages/Statistics";
import AdminDashboard from "./pages/AdminDashboard";

import RoleGuard from "./components/RoleGuard";
import AccountPage from "./pages/AccountPage";
import ChangePasswordPage from "./pages/ChangePasswordPage";


function App() {
  return (
    <Router>
      <Routes>
        <Route path="/login" element={<Login />} />
        <Route path="/signup" element={<Signup />} />
        <Route path="/complete-profile" element={<CompleteProfile />} />

        <Route path="/dashboard" element={<PrivateRoute><Dashboard /></PrivateRoute>} />
        <Route path="/upload" element={<PrivateRoute><Upload /></PrivateRoute>} />
        <Route path="/sepa/:id" element={<PrivateRoute><SepaDetailPage /></PrivateRoute>} />
        <Route path="/upload-zip" element={<PrivateRoute><UploadZip /></PrivateRoute>} />
        <Route path="/statistics" element={<Statistics />} />

        <Route
          path="/admin"
          element={
            <PrivateRoute>
              <RoleGuard need="ADMIN">
                <AdminDashboard />
              </RoleGuard>
            </PrivateRoute>
          }
        />

        <Route path="/account" element={<PrivateRoute><AccountPage /></PrivateRoute>} />
        <Route path="/account/password" element={<PrivateRoute><ChangePasswordPage /></PrivateRoute>} />
        
        <Route path="*" element={<Navigate to="/login" replace />} />
      </Routes>
    </Router>
  );
}

export default App;
