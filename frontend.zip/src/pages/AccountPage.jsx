// src/pages/AccountPage.jsx
import { useAuth } from "../store/AuthContext";
import { useState, useEffect } from "react";
import { updateMe } from "../api/account";
import { Link, useNavigate } from "react-router-dom";
import { useTranslation } from "react-i18next";

export default function AccountPage() {
  const { user, setUser } = useAuth();
  const [form, setForm] = useState({ first_name: "", last_name: "" });
  const navigate = useNavigate();
  const {t} = useTranslation();

  useEffect(() => {
    if (user) setForm({ first_name: user.first_name || "", last_name: user.last_name || "" });
  }, [user]);

  if (!user) return null;

  const onSave = async (e) => {
    e.preventDefault();
    await updateMe(form);
    // mets à jour le context pour refléter les changes localement
    setUser({ ...user, ...form });
    alert("Profil mis à jour.");
  };

  return (
    <div className="container py-4">
      <div>
        <h1 className="mb-3">Mon compte</h1>
        <button className="btn btn-primary"
          onClick={() => navigate("/dashboard")}
        >
          {t("upload.back_to_dashboard")}
        </button>
        <hr />
      </div>
      <div className="mb-3"><b>Email:</b> {user.email}</div>
      <div className="mb-3"><b>Rôle:</b> {user.role}</div>
      <form onSubmit={onSave} className="mb-3">
        <div className="mb-3">
          <label className="form-label">Prénom</label>
          <input className="form-control" value={form.first_name}
                 onChange={e=>setForm(f=>({...f, first_name:e.target.value}))}/>
        </div>
        <div className="mb-3">
          <label className="form-label">Nom</label>
          <input className="form-control" value={form.last_name}
                 onChange={e=>setForm(f=>({...f, last_name:e.target.value}))}/>
        </div>
        <button className="btn btn-dark">Enregistrer</button>
      </form>

      <Link className="btn btn-outline-secondary" to="/account/password">Changer le mot de passe</Link>
    </div>
  );
}
