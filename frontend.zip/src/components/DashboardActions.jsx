import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import axiosInstance from "../axiosInstance";
import { useTranslation } from "react-i18next";
import { FaBell } from "react-icons/fa";

const DashboardActions = ({ username }) => {
  const navigate = useNavigate();
  const { t } = useTranslation();

  const [notifications, setNotifications] = useState([]);
  const [showNotifications, setShowNotifications] = useState(false);

  const fetchNotifications = async () => {
    try {
      const res = await axiosInstance.get("/api/notifications/");
      setNotifications(res.data);
    } catch (error) {
      console.error("Erreur lors de la récupération des notifications :", error);
    }
  };

  const markAsRead = async (id) => {
    try {
      await axiosInstance.post(`/api/notifications/${id}/mark-read/`);
      setNotifications((prev) =>
        prev.map((n) => (n.id === id ? { ...n, is_read: true } : n))
      );
    } catch (err) {
      console.error("Erreur lors du marquage comme lu :", err);
    }
  };

  const markAllAsRead = async () => {
    try {
      await axiosInstance.post("/api/notifications/mark-read/");
      fetchNotifications(); // refresh après la MAJ
    } catch (err) {
      console.error("Erreur lors du marquage comme lues :", err);
    }
  };

  const handleToggleNotifications = async () => {
    const newState = !showNotifications;
    setShowNotifications(newState);

    if (newState) {
      await markAllAsRead();
    }
  };

  useEffect(() => {
    fetchNotifications();
  }, []);

  const handleLogout = () => {
    localStorage.removeItem("access");
    localStorage.removeItem("refresh");
    navigate("/login");
  };

  const handleUpdateVersions = async () => {
    const confirmed = window.confirm(t("dashboard.confirm_update_versions"));
    if (!confirmed) return;

    try {
      const res = await axiosInstance.post("/api/update-versions/", null);
      alert(t("dashboard.update_success", { count: res.data.updated }));
      window.location.reload();
    } catch (err) {
      alert(t("dashboard.update_error"));
      console.error(err);
    }
  };

  const hasUnread = notifications.some((n) => n.is_read === false);

  const sortedNotifications = [...notifications].sort((a, b) =>
    b.created_at.localeCompare(a.created_at)
  );

  return (
    <div className="card shadow text-center mb-5 p-4 position-relative">
      <div className="d-flex justify-content-between align-items-center mb-3">
        <h3 className="fw-bold text-primary m-0">
          {t("dashboard.welcome", { username })} 👋
        </h3>

        <button
          className="btn btn-light position-relative"
          onClick={handleToggleNotifications}
          title={t("dashboard.notifications")}
        >
          <FaBell size={24} />
          {hasUnread && (
            <span
              className="position-absolute top-0 start-100 translate-middle p-1 bg-danger border border-light rounded-circle"
              style={{ fontSize: "0.6rem" }}
            />
          )}
        </button>
      </div>

      <p className="lead">{t("dashboard.subtitle")}</p>

      <div className="d-flex flex-wrap justify-content-center gap-3 mt-4">
        <button
          className="btn btn-outline btn-lg text-dark border-dark"
          onClick={() => navigate("/upload")}
        >
          {t("dashboard.btn_validate")}
        </button>

        <button
          className="btn btn-outline btn-lg text-dark border-dark"
          onClick={() => navigate("/statistics")}
        >
          {t("dashboard.btn_statistics")}
        </button>

        <button
          className="btn btn-outline btn-lg text-dark border-dark"
          onClick={handleUpdateVersions}
        >
          {t("dashboard.btn_update_versions")}
        </button>

        <button
          className="btn btn-outline btn-lg text-dark border-dark"
          onClick={handleLogout}
        >
          {t("dashboard.btn_logout")}
        </button>
      </div>

      {showNotifications && (
        <div
          className="position-absolute end-0 top-0 mt-5 me-3 bg-white border p-3 shadow rounded"
          style={{
            width: "300px",
            maxHeight: "400px",
            overflowY: "auto",
            zIndex: 10,
          }}
        >
          <h6>{t("dashboard.notifications")}</h6>
          <ul className="list-unstyled mt-3">
            {sortedNotifications.length === 0 ? (
              <li>{t("dashboard.no_notifications")}</li>
            ) : (
              sortedNotifications.map((notif) => {
                const formattedDate = new Date(notif.created_at).toLocaleString();

                return (
                  <li
                    key={notif.id}
                    className={`mb-2 p-2 rounded d-flex flex-column ${
                      notif.is_read ? "bg-light" : "bg-warning"
                    }`}
                    onClick={() => markAsRead(notif.id)}
                    style={{ cursor: "pointer" }}
                  >
                    <strong>{notif.title}</strong>
                    <p className="mb-1 small">{notif.message}</p>
                    <span className="text-muted" style={{ fontSize: "0.75rem" }}>
                      {formattedDate}
                    </span>
                  </li>
                );
              })
            )}
          </ul>
        </div>
      )}
    </div>
  );
};

export default DashboardActions;
