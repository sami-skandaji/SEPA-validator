import React, { useEffect, useState, useCallback } from "react";
import Navbar from "./Navbar";
import DashboardActions from "./DashboardActions";
import axiosInstance from "../axiosInstance";
import { useNavigate } from "react-router-dom";
import { useTranslation } from "react-i18next";
import "../App.css";
import LanguageSwitcher from "./LanguageSwitcher";


const Dashboard = () => {
  const [username, setUsername] = useState("");
  const [files, setFiles] = useState([]);
  const [search, setSearch] = useState("");
  const [isValid, setIsValid] = useState("");
  const [ordering, setOrdering] = useState("-uploaded_at");
  const [filterVersion, setFilterVersion] = useState("");
  const [notifications, setNotifications] = useState([]);
  const [showNotifications, setShowNotifications] = useState(false);
  const { t } = useTranslation();

  const navigate = useNavigate();

  const fetchFiles = useCallback(() => {
    const params = new URLSearchParams();
    if (search) params.append("filename", search);
    if (isValid) params.append("is_valid", isValid);
    if (ordering) params.append("ordering", ordering);
    if (filterVersion) params.append("version", filterVersion);

    axiosInstance
      .get(`/api/results/?${params.toString()}`)
      .then((res) => {
        setFiles(res.data);
      })
      .catch((err) => {
        console.error(t("errors.fetchingFiles"), err);
      });
    }, [search, isValid, ordering, filterVersion, t]);

    const fetchNotifications = async () => {
      try {
        const res = await axiosInstance.get("/api/notifications/");
        setNotifications(res.data);
      } catch ( error ) {
        console.error("Erreur lors de la récupération des notifications : ", error);
      }
    };

    useEffect(() => {
      axiosInstance
        .get("/api/user-info/")
        .then((res) => setUsername(res.data.username));

      fetchFiles();
    }, [fetchFiles]);

    useEffect(() => {
      fetchFiles();
    }, [fetchFiles]);

    const handleDelete = async(id) => {
      if (window.confirm(t("actions.confirmDelete"))) {
        try {
          await axiosInstance.delete(`/api/results/${id}/delete/`);
          setFiles((prev) => prev.filter((file) => file.id !== id));
        } catch(err) {
          console.error(t("errors.deletingFile"), err);
        }
      }
    };

    const handleReviewResult = (id) => {
      navigate(`/sepa/${id}`);
    };

    
  return (
    <div className="container mt-5">
      <Navbar username={username} />
      <DashboardActions username={username} />

      <div className="text-end mb-3">
        <LanguageSwitcher />
      </div>
      <div className="card shadow p-4">
        <h4 className="mb-4 fw-bold text-primary text-center">
          {t("dashboard.title")}
        </h4>
        <div className="row g-3 mb-4">
          <div className="col-md-3">
            <label className="form-label">{t("dashboard.searchLabel")}</label>
            <input
              type="text"
              className="form-control"
              placeholder={t("dashboard.searchPlaceholder")}
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>
          <div className="col-md-2">
            <label className="form-label">{t("dashboard.validityLabel")}</label>
            <select
              className="form-select"
              value={isValid}
              onChange={(e) => setIsValid(e.target.value)}
            >
              <option value="">{t("dashboard.allOptions")}</option>
              <option value="true">{t("dashboard.validOption")}</option>
              <option value="false">{t("dashboard.invalidOption")}</option>
            </select>
          </div>
          <div className="col-md-3">
            <label className="form-label">{t("dashboard.sortLabel")}</label>
            <select
              className="form-select"
              value={ordering}
              onChange={(e) => setOrdering(e.target.value)}
            >
              <option value="-uploaded_at">{t("dashboard.sortRecent")}</option>
              <option value="uploaded_at">{t("dashboard.sortOldest")}</option>
              <option value="xml_file">{t("dashboard.sortAZ")}</option>
              <option value="-xml_file">{t("dashboard.sortZA")}</option>
              <option value="version">{t("dashboard.sortVersionAZ")}</option>
              <option value="-version">{t("dashboard.sortVersionZA")}</option>
            </select>
          </div>
          <div className="col-md-4">
            <label className="form-label">{t("dashboard.versionLabel")}</label>
            <input
              type="text"
              className="form-control"
              placeholder={t("dashboard.versionPlaceholder")}
              value={filterVersion}
              onChange={(e) => setFilterVersion(e.target.value)}
            />
          </div>
        </div>
        {files.length > 0 ? (
          <div className="table-responsive">
            <table className="table table-bordered table-striped table-hover text-center align-middle">
              <thead className="table-light">
                <tr>
                  <th>{t("dashboard.table.filename")}</th>
                  <th>{t("dashboard.table.uploadDate")}</th>
                  <th>{t("dashboard.table.valid")}</th>
                  <th>{t("dashboard.table.version")}</th>
                  <th>{t("dashboard.table.actions")}</th>
                </tr>
              </thead>
              <tbody>
                {files.map((file) => (
                  <tr key={file.id}>
                    <td>{file.filename}</td>
                    <td>{new Date(file.uploaded_at).toLocaleString()}</td>
                    <td>
                      {file.is_valid ? (
                        <span className="badge bg-success">{t("dashboard.badges.yes")}</span>
                      ) : (
                        <span className="badge bg-danger">{t("dashboard.badges.no")}</span>
                      )}
                    </td>
                    <td>{file.version || "-"}</td>
                    <td>
                      <div className="btn-group">
                        <button
                          className="btn btn-sm btn-outline text-dark border-dark"
                          onClick={() => handleReviewResult(file.id)}
                        >
                          {t("dashboard.actions.report")}
                        </button>
                        <button
                          className="btn btn-sm btn-outline text-dark border-dark"
                          onClick={() => handleDelete(file.id)}
                        >
                          {t("dashboard.actions.delete")}
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="alert alert-warning text-center mt-4">
            {t("dashboard.noResults")}
          </div>
        )}
      </div>
    </div>
  );
};

export default Dashboard;
