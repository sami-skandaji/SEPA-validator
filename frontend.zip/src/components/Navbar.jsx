// src/components/Navbar.jsx
import React from "react";
import { Link, useNavigate } from "react-router-dom";
import { useTranslation } from "react-i18next";
import { useAuth } from "../store/AuthContext";
import "../assets/styles.css";

const Navbar = () => {
  const navigate = useNavigate();
  const { t } = useTranslation();
  const { user, setUser } = useAuth();

  const handleLogout = () => {
    localStorage.removeItem("access");
    localStorage.removeItem("refresh");
    setUser(null);                // ✅ vide le contexte auth
    navigate("/login", { replace: true });
  };

  return (
    <nav className="navbar navbar-expand-lg navbar-light bg-light px-3">
      <button
        className="navbar-brand font-weight-bold btn btn-link"
        onClick={() => navigate("/dashboard")}
        style={{ textDecoration: "none" }}
      >
        SEPA Validator
      </button>

      <div className="collapse navbar-collapse">
        <ul className="navbar-nav mr-auto gap-3">
          {user && (
            <>
              <li className="nav-item">
                <Link className="nav-link" to="/dashboard">
                  {t("navbar.dashboard") || "Dashboard"}
                </Link>
              </li>
              <li className="nav-item">
                <Link className="nav-link" to="/account">
                  {t("navbar.account") || "Mon compte"}
                </Link>
              </li>
              {user.role === "ADMIN" && (
                <li className="nav-item">
                  <Link className="nav-link" to="/admin">
                    {t("navbar.moderation") || "Modération"}
                  </Link>
                </li>
              )}
            </>
          )}
        </ul>

        <div className="ms-auto d-flex align-items-center gap-3">
          {user ? (
            <>
              <span className="navbar-text">
                {t("navbar.logged_in_as")}{" "}
                <strong>
                  {user.first_name || user.email} 
                </strong>
              </span>
              <button onClick={handleLogout} className="btn btn-outline-danger">
                {t("navbar.logout")}
              </button>
            </>
          ) : (
            <Link to="/login" className="btn btn-outline-primary">
              {t("navbar.login") || "Se connecter"}
            </Link>
          )}
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
