from django.urls import path, include
from .api_views import (
    RegisterAPIView,
    CustomAuthToken,
    SepaUploadAPIView,
    SepaValidationResultListAPIView,
    SepaValidationDetailAPIView,
    SepaValidationDeleteAPIView,
    SepaFileUpdateAPIView,
    SepaSummaryView,
    UserInfoAPIView,
    UpdateSepaVersionsAPIView,
    ValidateFromURLAPIView,
    UploadFromURLAPIView,
    UploadZipFile,
    NotificationListAPIView,
    MarkNotificationAsReadAPIView,
    SepaStatisticsAPIView,
    StatisticsTimeSeriesAPIView,
    MeView
)
from .admin_views import (
    SepaFileModerationList,
    SepaFileModerationDetail,
    SepaFileRevalidate,
    SepaFileSetValidity
)

urlpatterns = [
    path('register/', RegisterAPIView.as_view(), name='register'),
    path('login/', CustomAuthToken.as_view(), name='api-login'),
    path('user-info/', UserInfoAPIView.as_view(), name='user-info'),

    path('upload/', SepaUploadAPIView.as_view(), name='sepa-upload'),
    path('results/', SepaValidationResultListAPIView.as_view(), name='sepa-results'),
    path('results/<int:pk>/', SepaValidationDetailAPIView.as_view(), name='sepa-result-detail'),
    path('results/<int:pk>/delete/', SepaValidationDeleteAPIView.as_view(), name='sepa-result-delete'),
    path('results/<int:pk>/update/', SepaFileUpdateAPIView.as_view(), name='sepa-update'),

    path('files/<int:id>/', SepaValidationDetailAPIView.as_view(), name='sepa-file-detail'),  # <- ajouté pour le frontend

    path('update-versions/', UpdateSepaVersionsAPIView.as_view(), name='update_versions'),
    path('summary/', SepaSummaryView.as_view(), name='sepa-summary'),
    path('validate-url/', ValidateFromURLAPIView.as_view(), name='validate-from-url'),
    path('upload-url/', UploadFromURLAPIView.as_view(), name='upload-from-url'),
    path("upload-zip/", UploadZipFile.as_view(), name="upload-zip"),
    path("notifications/", NotificationListAPIView.as_view(), name='notifications-list'),
    path("notifications/<int:pk>/mark-read/", MarkNotificationAsReadAPIView.as_view(), name="mark-notification-read"),
    path("statistics/", SepaStatisticsAPIView.as_view(), name="sepa-statistics"),
    path("statistics/timeseries/", StatisticsTimeSeriesAPIView.as_view(), name="statistics_timeseries"),
    path("moderation/files/", SepaFileModerationList.as_view(), name="sepa-admin-list"),
    path("moderation/files/<int:pk>/", SepaFileModerationDetail.as_view(), name="sepa-admin-detail"),
    path("moderation/files/<int:pk>/revalidate/", SepaFileRevalidate.as_view(), name="sepa-admin-revalidate"),
    path("moderation/files/<int:pk>/set-validity/", SepaFileSetValidity.as_view(), name="sepa-admin-set-validity"),
    path("accounts/", include("accounts.urls")),
]
