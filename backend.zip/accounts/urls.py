# accounts/urls.py
from django.urls import path
from .views import MeView, MeUpdateView, ChangePasswordView

urlpatterns = [
    path("me/", MeView.as_view(), name="me"),
    path("me/update/", MeUpdateView.as_view(), name="me-update"),
    path("me/change-password/", ChangePasswordView.as_view(), name="change-password"),
]
