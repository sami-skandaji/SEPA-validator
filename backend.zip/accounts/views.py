# accounts/views.py
from rest_framework.views import APIView
from rest_framework import generics, status
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from django.contrib.auth import update_session_auth_hash, get_user_model
from .serializers import MeSerializer, MeUpdateSerializer, ChangePasswordSerializer

User = get_user_model()

class MeView(APIView):
    permission_classes = [IsAuthenticated]
    def get(self, request):
        return Response(MeSerializer(request.user).data)

class MeUpdateView(generics.UpdateAPIView):
    permission_classes = [IsAuthenticated]
    serializer_class = MeUpdateSerializer
    def get_object(self):
        return self.request.user

class ChangePasswordView(APIView):
    permission_classes = [IsAuthenticated]
    def post(self, request):
        s = ChangePasswordSerializer(data=request.data)
        s.is_valid(raise_exception=True)
        user = request.user
        if not user.check_password(s.validated_data["old_password"]):
            return Response({"detail": "Ancien mot de passe incorrect."}, status=400)
        user.set_password(s.validated_data["new_password"])
        user.save()
        # si tu gardes des sessions en plus du JWT
        update_session_auth_hash(request, user)
        return Response({"detail": "Mot de passe changé."})
